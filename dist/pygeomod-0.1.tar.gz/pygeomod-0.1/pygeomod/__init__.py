'''Module initialisation for pygeomod
Created on 21/03/2014

@author: Florian
'''

if __name__ == '__main__':
    pass 